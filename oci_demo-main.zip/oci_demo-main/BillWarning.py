import main

if __name__ == '__main__':
    # @ 4:
    # 账单监控
    main.get_BillWarning()
